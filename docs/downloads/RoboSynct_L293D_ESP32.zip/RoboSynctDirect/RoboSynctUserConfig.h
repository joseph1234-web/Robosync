#pragma once
// Use Easy ESP32 setup to download a PRIVATE replacement for this file.
// Leave these empty to retain the existing physical-code enrollment route.
#define ROBOSYNCT_DEVICE_TAG ""
#define ROBOSYNCT_SETUP_KEY_HEX ""
#define ROBOSYNCT_AP_PASSWORD ""
#define ROBOSYNCT_USE_CONFIGURED_WIFI 0
#define ROBOSYNCT_HOME_SSID ""
#define ROBOSYNCT_HOME_PASSWORD ""

#define ROBOSYNCT_MOTOR_PROFILE 2
#define ROBOSYNCT_WIRING_CONFIRMED 0
