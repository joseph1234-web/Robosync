# RoboSynct L293D · ESP32 DevKit V1

Use this sketch on the dedicated original ESP32 DevKit V1 for the motor widget. Keep your sensor, RGB, and relay sketch on its ESP32.

## Pin streams

| App signal | Driver | ESP32 | Signal type |
|---|---|---|---|
| ENA | 1,2EN · 1 | GPIO25 | PWM enable |
| IN1 | 1A · 2 | GPIO27 | Digital direction |
| IN2 | 2A · 7 | GPIO32 | Digital direction |
| IN3 | 3A · 10 | GPIO33 | Digital direction |
| IN4 | 4A · 15 | GPIO23 | Digital direction |
| ENB | 3,4EN · 9 | GPIO26 | PWM enable |

For the 16-pin L293D, connect motor A across pins 3 and 6 and motor B across pins 11 and 14. Pin 16 is the 5 V logic supply, pin 8 is the motor supply, and pins 4, 5, 12, and 13 are ground.

Use a motor supply sized for the motors' voltage and stall current. Share ground with the ESP32. Add a 10 kΩ pull-down at each enable input so both bridges stay disabled while the ESP32 resets. Keep 5 V and motor supply voltage away from ESP32 GPIOs.

## Set up

1. With motor power off, check the wiring. Set ROBOSYNCT_WIRING_CONFIRMED to 1 in RoboSynctUserConfig.h after checking.
2. Open RoboSynctDirect/RoboSynctDirect.ino with Arduino ESP32 3.3.12. Select ESP32 Dev Module and the Huge APP partition on the dedicated motor board, then verify and upload. Keep Erase All Flash disabled to retain an existing board key.
3. Open the motor widget on your phone. Connect via Bluetooth or local Wi-Fi and choose Use connected board. Use the 115200 baud Serial Monitor for physical BOOT enrollment if needed.
4. Raise the wheels clear for the first test. Arm and hold one arrow. Check Stop, release, backgrounding and link loss before driving on the floor. Remove motor power if a wheel fails to stop.

The six pin streams show the current signal reported by the paired board. They are local to the phone.

[TI L293D datasheet](https://www.ti.com/lit/ds/symlink/l293d.pdf)

[ST L298 datasheet](https://www.st.com/resource/en/datasheet/l298.pdf)
