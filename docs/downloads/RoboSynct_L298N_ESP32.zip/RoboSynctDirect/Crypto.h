#pragma once
#include <Arduino.h>
#include <esp_system.h>
#include <mbedtls/gcm.h>
#include <mbedtls/md.h>
#include <mbedtls/sha256.h>

namespace RSD {
constexpr size_t MAX_FRAME=256;
inline void put32(uint8_t* p,uint32_t n){p[0]=n>>24;p[1]=n>>16;p[2]=n>>8;p[3]=n;}
inline uint32_t get32(const uint8_t* p){return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
inline String hex(const uint8_t* p,size_t n){String s;for(size_t i=0;i<n;i++){char b[3];snprintf(b,3,"%02x",p[i]);s+=b;}return s;}
inline bool seal(const uint8_t* key,const uint8_t* hello,uint8_t kind,const uint8_t* plain,size_t n,uint8_t* out,size_t& size){
 if(n+30>MAX_FRAME)return false;
 out[0]=1;out[1]=kind;esp_fill_random(out+2,12);uint8_t aad[37];memcpy(aad,hello,36);aad[36]=kind;
 mbedtls_gcm_context c;mbedtls_gcm_init(&c);int r=mbedtls_gcm_setkey(&c,MBEDTLS_CIPHER_ID_AES,key,256);
 if(!r)r=mbedtls_gcm_crypt_and_tag(&c,MBEDTLS_GCM_ENCRYPT,n,out+2,12,aad,sizeof(aad),plain,out+14,16,out+14+n);
 mbedtls_gcm_free(&c);size=n+30;return r==0;
}
inline bool open(const uint8_t* key,const uint8_t* hello,uint8_t kind,const uint8_t* frame,size_t n,uint8_t* out,size_t& size){
 if(n<30||n>MAX_FRAME||frame[0]!=1||frame[1]!=kind)return false;
 uint8_t aad[37];memcpy(aad,hello,36);aad[36]=kind;
 mbedtls_gcm_context c;mbedtls_gcm_init(&c);int r=mbedtls_gcm_setkey(&c,MBEDTLS_CIPHER_ID_AES,key,256);size=n-30;
 if(!r)r=mbedtls_gcm_auth_decrypt(&c,size,frame+2,12,aad,sizeof(aad),frame+n-16,16,frame+14,out);
 mbedtls_gcm_free(&c);return r==0;
}
inline void setupKey(const uint8_t* code,const uint8_t* id,uint8_t* out){uint8_t b[42];memcpy(b,code,16);memcpy(b+16,id,8);memcpy(b+24,"RoboSynct setup v1",18);mbedtls_sha256(b,sizeof(b),out,0);}
inline void sessionKey(const uint8_t* owner,const uint8_t* hello,const uint8_t* client,uint8_t* out){uint8_t b[71];memcpy(b,hello,36);memcpy(b+36,client,16);memcpy(b+52,"RoboSynct direct v1",19);mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),owner,32,b,sizeof(b),out);}
}
