#pragma once
#include <stdint.h>

// Pure state machine, shared by the firmware and executable host bench tests.
class RoboSynctSafety {
 public:
  explicit RoboSynctSafety(bool enabled):enabled_(enabled){}
  static bool fresh(uint32_t now,uint32_t deadline){int32_t remaining=static_cast<int32_t>(deadline-now);return remaining>0&&remaining<=500;}
  bool arm(uint64_t owner,uint32_t now){tick(now);if(!enabled_||(armed_&&owner_!=owner))return false;left_=right_=0;owner_=owner;armed_=true;armedAt_=lastDrive_=now;return true;}
  bool drive(uint64_t owner,uint32_t now,int left,int right){tick(now);if(!armed_||owner!=owner_||left< -100||left>100||right< -100||right>100)return false;left_=limit(left);right_=limit(right);lastDrive_=now;return true;}
  void stop(bool disarm=false){left_=right_=0;if(disarm){armed_=false;owner_=0;}}
  void lost(uint64_t owner){if(owner_==owner)stop(true);}
  void tick(uint32_t now){if(armed_&&static_cast<uint32_t>(now-armedAt_)>=10000)stop(true);else if(static_cast<uint32_t>(now-lastDrive_)>=350)stop(false);}
  bool armed()const{return armed_;}bool enabled()const{return enabled_;}bool moving()const{return left_||right_;}int left()const{return left_;}int right()const{return right_;}
 private:
  static int limit(int n){return n>35?35:n< -35? -35:n;}
  bool enabled_=false,armed_=false;uint64_t owner_=0;uint32_t armedAt_=0,lastDrive_=0;int left_=0,right_=0;
};
