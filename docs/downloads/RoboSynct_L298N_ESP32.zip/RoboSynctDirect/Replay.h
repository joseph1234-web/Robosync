#pragma once
#include <stdint.h>
#include "Safety.h"

// A challenge is consumed once. Clearing authentication must not make it reusable.
class RoboSynctReplay {
 public:
  bool handshakeUsed()const{return used_;}
  void consumeHandshake(){used_=true;last_=0;}
  void newChallenge(){used_=false;last_=0;}
  uint8_t command(uint32_t sequence,uint32_t now,uint32_t deadline){
   if(!sequence||sequence>0x7fffffff||sequence<=last_)return 2;
   last_=sequence;
   return RoboSynctSafety::fresh(now,deadline)?0:3;
  }
 private:bool used_=false;uint32_t last_=0;
};
