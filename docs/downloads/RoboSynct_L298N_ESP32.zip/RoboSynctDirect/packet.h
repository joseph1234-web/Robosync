#pragma once
#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>

// Pure formatter is also exercised by the host C++/Python contract test.
static inline int formatRoboSynctSample(char* out, size_t capacity, const char* boot,
                                      uint32_t sequence, uint64_t uptimeMs, uint16_t raw) {
  if (raw > 4095) return -1;
  return snprintf(out, capacity,
    "{\"protocol\":\"robosynct-usb-sensor\",\"version\":1,\"firmware\":\"1.0.0\","
    "\"board\":\"esp32-devkit-v1\",\"boot\":\"%s\",\"seq\":%" PRIu32 ","
    "\"uptime_ms\":%" PRIu64 ",\"channel\":\"pot_raw\",\"value\":%u,\"source\":\"hardware\"}",
    boot, sequence, uptimeMs, static_cast<unsigned>(raw));
}
