#pragma once
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include "Safety.h"

// Network, NVS and BLE callbacks never hold this mutex. A separate higher-
// priority task evaluates STOP even when the application loop is blocked in I/O.
class RoboSynctMotorRuntime {
 public:
  explicit RoboSynctMotorRuntime(bool enabled):policy_(enabled){}
  bool begin(){
   if(policy_.enabled()&&!startPins())return false;
   lock_=xSemaphoreCreateMutex();
   if(!lock_||xTaskCreate(task,"rs-motor-watchdog",3072,this,4,&watchdog_)!=pdPASS){
    if(policy_.enabled())disablePins();
    return false;
   }
   return true;
  }
  bool arm(uint64_t owner,uint32_t now){take();bool ok=ready_&&policy_.arm(owner,now);applyLocked();ok=ok&&ready_;give();return ok;}
  bool drive(uint64_t owner,uint32_t now,int left,int right){take();bool ok=ready_&&policy_.drive(owner,now,left,right);applyLocked();ok=ok&&ready_;give();return ok;}
  void stop(bool disarm=false){take();policy_.stop(disarm);applyLocked();give();}
  void lost(uint64_t owner){take();policy_.lost(owner);applyLocked();give();}
  void tick(uint32_t now){take();policy_.tick(now);applyLocked();give();}
  void apply(){take();applyLocked();give();}
  uint8_t flags(uint8_t* state=nullptr){
   take();
   uint8_t flags=ready_?1|(policy_.armed()?2:0)|(policy_.moving()?4:0):0;
#if ROBOSYNCT_MOTOR_PROFILE==2 || ROBOSYNCT_MOTOR_PROFILE==3
   if(state&&ready_){
    state[0]='M';state[1]=1;state[2]=ROBOSYNCT_MOTOR_PROFILE;
    state[3]=uint8_t(policy_.left());state[4]=uint8_t(policy_.right());
   }
#endif
   give();
   return flags;
  }
 private:
  RoboSynctSafety policy_;
  SemaphoreHandle_t lock_=nullptr;
  TaskHandle_t watchdog_=nullptr;
  int oldLeft_=0,oldRight_=0;
  bool ready_=false;
  static constexpr int ENA=25,ENB=26;
#if ROBOSYNCT_MOTOR_PROFILE==1
  static constexpr int IN1=18,IN2=19,IN3=21,IN4=22,STBY=27;
#else
  static constexpr int IN1=27,IN2=32,IN3=33,IN4=23;
#endif
  void take(){if(lock_)xSemaphoreTake(lock_,portMAX_DELAY);}
  void give(){if(lock_)xSemaphoreGive(lock_);}
  static void task(void* arg){auto self=static_cast<RoboSynctMotorRuntime*>(arg);for(;;){self->tick(millis());TickType_t delay=pdMS_TO_TICKS(5);vTaskDelay(delay?delay:1);}}
  static void outputLow(int pin){pinMode(pin,OUTPUT);digitalWrite(pin,LOW);}
  void disablePins(){
   ready_=false;
   policy_.stop(true);
#if ROBOSYNCT_MOTOR_PROFILE!=0
#if ROBOSYNCT_MOTOR_PROFILE==1
   outputLow(STBY);
#endif
   ledcDetach(ENA);ledcDetach(ENB);
   outputLow(ENA);outputLow(ENB);
   outputLow(IN1);outputLow(IN2);outputLow(IN3);outputLow(IN4);
#endif
  }
  bool startPins(){
#if ROBOSYNCT_MOTOR_PROFILE!=0
   outputLow(ENA);outputLow(ENB);
#if ROBOSYNCT_MOTOR_PROFILE==1
   outputLow(STBY);
#endif
   outputLow(IN1);outputLow(IN2);outputLow(IN3);outputLow(IN4);
   constexpr int frequency=ROBOSYNCT_MOTOR_PROFILE==1?20000:1000;
   ready_=ledcAttach(ENA,frequency,8)&&ledcAttach(ENB,frequency,8)
      &&ledcWrite(ENA,0)&&ledcWrite(ENB,0);
   if(!ready_)disablePins();
#endif
   return ready_;
  }
  void applyLocked(){
#if ROBOSYNCT_MOTOR_PROFILE!=0
   if(!ready_)return;
   int left=policy_.left(),right=policy_.right();
   if(left==oldLeft_&&right==oldRight_)return;
#if ROBOSYNCT_MOTOR_PROFILE==1
   digitalWrite(STBY,LOW);
#endif
   // Disable both bridges before changing polarity, even when only one side reverses.
   if(!ledcWrite(ENA,0)||!ledcWrite(ENB,0)){disablePins();return;}
   digitalWrite(IN1,left>0);digitalWrite(IN2,left<0);
   digitalWrite(IN3,right>0);digitalWrite(IN4,right<0);
   if(!ledcWrite(ENA,abs(left)*255/100)||!ledcWrite(ENB,abs(right)*255/100)){disablePins();return;}
   oldLeft_=left;oldRight_=right;
#if ROBOSYNCT_MOTOR_PROFILE==1
   digitalWrite(STBY,policy_.armed()&&policy_.moving()?HIGH:LOW);
#endif
#endif
  }
};
