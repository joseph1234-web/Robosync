# RoboSynct L298N · ESP32 DevKit V1

Use this sketch on the dedicated original ESP32 DevKit V1 for the motor widget. Keep your sensor, RGB, and relay sketch on its ESP32.

## Pin streams

| App signal | Driver | ESP32 | Signal type |
|---|---|---|---|
| ENA | ENA | GPIO25 | PWM enable |
| IN1 | IN1 | GPIO27 | Digital direction |
| IN2 | IN2 | GPIO32 | Digital direction |
| IN3 | IN3 | GPIO33 | Digital direction |
| IN4 | IN4 | GPIO23 | Digital direction |
| ENB | ENB | GPIO26 | PWM enable |

Remove the ENA and ENB jumpers before wiring those inputs. The 5V_EN jumper configures the module's logic regulator. Follow the supply markings and documentation for your module. Connect motor A to OUT1/OUT2 and motor B to OUT3/OUT4.

Use a motor supply sized for the motors' voltage and stall current. Share ground with the ESP32. Add a 10 kΩ pull-down at each enable input so both bridges stay disabled while the ESP32 resets. Keep 5 V and motor supply voltage away from ESP32 GPIOs.

## Set up

1. With motor power off, check the wiring. Set ROBOSYNCT_WIRING_CONFIRMED to 1 in RoboSynctUserConfig.h after checking.
2. Open RoboSynctDirect/RoboSynctDirect.ino with Arduino ESP32 3.3.12. Select ESP32 Dev Module and the Huge APP partition on the dedicated motor board, then verify and upload. Keep Erase All Flash disabled to retain an existing board key.
3. Open the motor widget on your phone. Connect via Bluetooth or local Wi-Fi and choose Use connected board. Use the 115200 baud Serial Monitor for physical BOOT enrollment if needed.
4. Raise the wheels clear for the first test. Arm and hold one arrow. Check Stop, release, backgrounding and link loss before driving on the floor. Remove motor power if a wheel fails to stop.

The six pin streams show the current signal reported by the paired board. They are local to the phone.

[TI L293D datasheet](https://www.ti.com/lit/ds/symlink/l293d.pdf)

[ST L298 datasheet](https://www.st.com/resource/en/datasheet/l298.pdf)
